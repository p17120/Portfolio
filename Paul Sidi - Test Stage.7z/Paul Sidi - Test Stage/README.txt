When building a logging framework for C# theres 3 main librarys that we should consider (log4j, log4net, Serilog). I gave special attention to three main concerns: recording, formatting, and appending

Thats why i chose Serilog . The API is more modern, it is easier to set up, it is better maintained and it does structured logging by default. The ability to add enrichers give you the ability to intercept and modify the messages is jolly useful. 

I set up Serilog . Set up the way that recording is made and put special attention on the details that the logs would use . Every log made has every detail the programmer will need to investigate a problem. 

The proccess gives us 2 files log.txt and log.json this provides us the ability to format the logs however we see fit . You can simply load the log.json file and automatically format it through VS .

Furthermore i made some settings so i can work with SEQ (https://datalust.co/seq) . Seq creates the visibility you need to quickly identify and diagnose problems in complex applications and microservices. This means that we can quickly set up a UI for the logs and even the less experienced members of the team will be able to use it with easy due to the simplicity of it (Note: This feature is currently disabled cause it requires an account to be made but it can be set up in a matter of minutes)

This is my way of quickly and effienctly making a logging framework . Thank you for you time . 


----****IMPORTANT****----

Before you run the application you should link the file in which you want your logs to be created in 
appsettings.json . The 2 objects with "Name": "File".
Hardcode your path in both  "path".
You may need to create a log.txt inside the folder or simply delete that function and have the logs be created in a log.json file automatically
